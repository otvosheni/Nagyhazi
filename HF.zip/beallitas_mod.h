//
// Created by Heni on 2018. 11. 08..
//

#ifndef HF_BEALLITAS_MOD_H
#define HF_BEALLITAS_MOD_H

void beallitas_mod();

#endif //HF_BEALLITAS_MOD_H
