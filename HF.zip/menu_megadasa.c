//
// Created by Heni on 2018. 11. 08..
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "menu_megadasa.h"
#include "strukturak.h"


void menu_megadasa(){
    printf("Menü megadása:\n\n");

    int eloetelek_db;
    printf("Hányféle előételt szeretne megadni? ");
    scanf("%d", &eloetelek_db);

    Etel *eloetelek = (Etel*) malloc(sizeof(Etel)*eloetelek_db);

    printf("Kérem sorolja fel:\n");
    for(int i=0; i < eloetelek_db; i++){
        char nevek[64];
        int arak;
        printf("%d. Neve: ", i+1);
        scanf("%s", nevek);
        printf("Ára(Ft): ");
        scanf("%d", &arak);
        printf("\n");

        Etel eloetel;
        strcpy(eloetel.neve, nevek);
        eloetel.ara = arak;
        eloetelek[i] = eloetel;
    }

    int foetelek_db;
    printf("Hányféle főételt szeretne megadni? ");
    scanf("%d", &foetelek_db);

    Etel *foetelek = (Etel*) malloc(sizeof(Etel)*foetelek_db);

    printf("Kérem sorolja fel:\n");
    for(int i=0; i < foetelek_db; i++){
        char nevek[64];
        int arak;
        printf("%d. Neve: ", i+1);
        scanf("%s", nevek);
        printf("Ára(Ft): ");
        scanf("%d", &arak);
        printf("\n");

        Etel foetel;
        strcpy(foetel.neve, nevek);
        foetel.ara = arak;
        foetelek[i] = foetel;
    }

    int desszertek_db;
    printf("Hányféle desszertet szeretne megadni? ");
    scanf("%d", &desszertek_db);

    Etel *desszertek = (Etel*) malloc(sizeof(Etel)*desszertek_db);

    printf("Kérem sorolja fel:\n");
    for(int i=0; i < desszertek_db; i++){
        char nevek[64];
        int arak;
        printf("%d. Neve: ", i+1);
        scanf("%s", nevek);
        printf("Ára(Ft): ");
        scanf("%d", &arak);
        printf("\n");

        Etel desszert;
        strcpy(desszert.neve, nevek);
        desszert.ara = arak;
        desszertek[i] = desszert;
    }

    int italok_db;
    printf("Hányféle italt szeretne megadni? ");
    scanf("%d", &italok_db);

    Etel *italok = (Etel*) malloc(sizeof(Etel)*italok_db);

    printf("Kérem sorolja fel:\n");
    for(int i=0; i < italok_db; i++){
        char nevek[64];
        int arak;
        printf("%d. Neve: ", i+1);
        scanf("%s", nevek);
        printf("Ára(Ft): ");
        scanf("%d", &arak);
        printf("\n");

        Etel ital;
        strcpy(ital.neve, nevek);
        ital.ara = arak;
        italok[i] = ital;
    }

    FILE *file = fopen("menu.dat", "wt");
    fprintf(file, "eloetelek");
    for (int i = 0; i < eloetelek_db; i++) {
        Etel kaja = eloetelek[i];
        fprintf(file, "%s;%d\n", kaja.neve, kaja.ara);
    }
    fprintf(file, "foetelek");
    for (int i = 0; i < foetelek_db; i++) {
        Etel kaja = foetelek[i];
        fprintf(file, "%s;%d\n", kaja.neve, kaja.ara);
    }
    fprintf(file, "desszertek");
    for (int i = 0; i < desszertek_db; i++) {
        Etel kaja = desszertek[i];
        fprintf(file, "%s;%d\n", kaja.neve, kaja.ara);
    }
    fprintf(file, "italok");
    for (int i = 0; i < italok_db; i++) {
        Etel kaja = italok[i];
        fprintf(file, "%s;%d\n", kaja.neve, kaja.ara);
    }
    fclose(file);

    int szam;
    printf("Ha végzett, akkor nyomja meg a 3-as gombot, hogy visszamehessen a főmenübe\n");
    scanf("%d", &szam);
    system("cls");

    if (szam == 3)
        return;

}