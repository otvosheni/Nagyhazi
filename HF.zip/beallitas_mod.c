//
// Created by Heni on 2018. 11. 08..
//

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "beallitas_mod.h"
#include "asztalok_megadasa.h"
#include "menu_megadasa.h"

void beallitas_mod() {
    int szam;
    printf("1. Asztalok megadása\n");
    printf("2. Menü megadása\n");
    printf("3. Visszalépés a főmenübe\n");
    printf("Kérem válasszon az ezen menüpontok közül: ");
    scanf("%d", &szam);
    system("cls"); // only on windows

    if (szam != 1 && szam != 2 && szam != 3)
        printf("Érvénytelen a bemenet, kérem próbálja újra!");

    if (szam == 1)
        asztalok_megadasa();
    if (szam == 2)
        menu_megadasa();
    if (szam == 3)
        return;
}
