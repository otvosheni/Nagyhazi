//
// Created by Heni on 2018. 11. 08..
//

#ifndef HF_ASZTALOK_MEGADASA_H
#define HF_ASZTALOK_MEGADASA_H

void asztalok_megadasa();

#endif //HF_ASZTALOK_MEGADASA_H
