//
// Created by Heni on 2018. 11. 08..
//

#ifndef HF_MENU_MEGADASA_H
#define HF_MENU_MEGADASA_H

void menu_megadasa();

#endif //HF_MENU_MEGADASA_H
