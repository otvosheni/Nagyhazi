//
// Created by Heni on 2018. 11. 22..
//

#ifndef HF_SZAMLA_KIALLITASA_H
#define HF_SZAMLA_KIALLITASA_H

#include "strukturak.h"

void szamla_kiallitasa(egy_Asztal *asztaltomb,int *hossz);

#endif //HF_SZAMLA_KIALLITASA_H
