//
// Created by Heni on 2018. 11. 14..
//

#ifndef HF_FELHASZNALO_MOD_H
#define HF_FELHASZNALO_MOD_H

#include "strukturak.h"

void felhasznalo_mod(egy_Asztal *asztaltomb,int *hossz, Menu menu);

#endif //HF_FELHASZNALO_MOD_H
