//
// Created by Heni on 2018. 11. 08..
//

#ifndef HF_BEALLITAS_MOD_H
#define HF_BEALLITAS_MOD_H

#include "strukturak.h"

void fajlbol_olvasas(egy_Asztal** asztaltomb,int *hossz, Menu* menutomb);
void beallitas_mod(egy_Asztal** asztaltomb,int *hossz, Menu* menutomb);

#endif //HF_BEALLITAS_MOD_H
