//
// Created by Heni on 2018. 11. 08..
//

#ifndef HF_ASZTALOK_MEGADASA_H
#define HF_ASZTALOK_MEGADASA_H

#include "strukturak.h"

egy_Asztal *asztalok_megadasa(int *hossz);
egy_Asztal *asztalok_beolvas(int *hossz);

#endif //HF_ASZTALOK_MEGADASA_H
