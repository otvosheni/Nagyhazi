//
// Created by Heni on 2018. 11. 18..
//

#ifndef HF_ASZTALFOGLALAS_H
#define HF_ASZTALFOGLALAS_H

void asztalfoglalas();
void foglalas_megadasa();
void foglalasok_listazasa();


#endif //HF_ASZTALFOGLALAS_H
