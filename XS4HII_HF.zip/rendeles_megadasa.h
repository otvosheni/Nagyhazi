//
// Created by Heni on 2018. 11. 22..
//

#ifndef HF_RENDELES_MEGADASA_H
#define HF_RENDELES_MEGADASA_H

#include "strukturak.h"

void egy_rendeles_megadasa(egy_Asztal* asztal, int *hossz, Menu menu);
Etel *etel_leker(Menu menu, char *szoveg);

#endif //HF_RENDELES_MEGADASA_H
